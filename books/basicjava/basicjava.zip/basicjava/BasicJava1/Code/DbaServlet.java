import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.sql.*;
import java.net.*;
import java.io.*;

public class DbaServlet extends HttpServlet {

    private Connection c;
    final static private String _driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    final static private String _user = "username";
    final static private String _pass = "password";
    final static private String _url = "jdbc:odbc:jdc";


    public void doPost(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException
   {
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
        out.println("<title>Example</title>" +
                     "<body bgcolor=FFFFFF>");

        out.println("<h2>Button Clicked</h2>");

        String DATA = request.getParameter("DATA");

        if(DATA != null){
		out.println("<STRONG>Text from form:</STRONG>");
                out.println(DATA);
        } else {
                out.println("No text entered.");
        }

//Establish database connection
        try{
          Class.forName (_driver);
          c = DriverManager.getConnection(_url, _user,_pass);
        }catch (java.sql.SQLException e){
          System.out.println("Cannot get connection");       
          System.exit(1);
        }catch (java.lang.ClassNotFoundException e) {
          System.out.println("Driver class not found");
        }

        try{
//Code to write to database
          Statement stmt = c.createStatement();
          String updateString = "INSERT INTO dba " + "VALUES ('" + DATA + "')";
          int count = stmt.executeUpdate(updateString);

//Code to read from database
          ResultSet results = stmt.executeQuery("SELECT TEXT FROM dba ");
          while(results.next()){
            String s = results.getString("TEXT");
            out.println("<BR><STRONG>Text from database:</STRONG>");
            out.println(s);
        }
         stmt.close();
        }catch(java.sql.SQLException e){
         System.out.println("Cannot create SQL statement");
         System.exit(1);
        }

        out.println("<P>Return to <A HREF=../dbaHTML.html>Form</A>");
        out.close();
   }
}
