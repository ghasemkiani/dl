import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import java.io.*;

class Dba extends JFrame implements ActionListener {

   JLabel text, clicked;
   JButton button, clickButton;
   JPanel panel;
   JTextField textField;
   private boolean _clickMeMode = true;

   private Connection c;

   final static private String _driver = "oracle.jdbc.driver.OracleDriver";
   final static private String _url = "jdbc:oracle:thin:username/password@(description=(address_list=(address=(protocol=tcp)(host=developer)(port=1521)))(source_route=yes)(connect_data=(sid=ansid)))";


   Dba(){ //Begin Constructor
     text = new JLabel("Text to save to database:");
     button = new JButton("Click Me");
     button.addActionListener(this);
     textField = new JTextField(20);
     panel = new JPanel();
     panel.setLayout(new BorderLayout());
     panel.setBackground(Color.white);
     getContentPane().add(panel);
     panel.add(BorderLayout.NORTH, text);
     panel.add(BorderLayout.CENTER, textField);
     panel.add(BorderLayout.SOUTH, button);
   } //End Constructor

   public void actionPerformed(ActionEvent event){
     try{
// Load the Driver
        Class.forName (_driver);
// Make Connection
        c = DriverManager.getConnection(_url);
      }
      catch (java.lang.ClassNotFoundException e){
       System.out.println("Cannot find driver class");
       System.exit(1);
      }catch (java.sql.SQLException e){
       System.out.println("Cannot get connection");
       System.exit(1);
      }

     Object source = event.getSource();
     if(source == button){
       if(_clickMeMode){
         JTextArea displayText = new JTextArea();
         try{
      //Code to write to database
          String theText = textField.getText();
          Statement stmt = c.createStatement();
          String updateString = "INSERT INTO dba VALUES ('" + theText + "')";
         int count = stmt.executeUpdate(updateString);
     //Code to read from database
         ResultSet results = stmt.executeQuery("SELECT TEXT FROM dba "); 
         while(results.next()){
           String s = results.getString("TEXT");
           displayText.append(s + "\n");
         }
         stmt.close();
       }catch(java.sql.SQLException e){
        System.out.println("Cannot create SQL statement");
       }

      //Display text read from database
        text.setText("Text retrieved from database:");
        button.setText("Click Again");
        _clickMeMode = false;
//Display text read from database
      } else {
        text.setText("Text to save to database:");
        textField.setText("");
        button.setText("Click Me");
        _clickMeMode = true;
      }
   }
}

   public static void main(String[] args){
      Dba frame = new Dba();
      frame.setTitle("Example");
      WindowListener l = new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
          System.exit(0);
        }
      };
      frame.addWindowListener(l);
      frame.pack();
      frame.setVisible(true);
    }
}
